/**************************************************************
 *
 * userprog/ksyscall.h
 *
 * Kernel interface for systemcalls 
 *
 * by Marcus Voelp  (c) Universitaet Karlsruhe
 *
 **************************************************************/

#ifndef __USERPROG_KSYSCALL_H__ 
#define __USERPROG_KSYSCALL_H__ 

#include "kernel.h"
#include "filesys.h"




void SysHalt()
{
  kernel->interrupt->Halt();
}


int SysAdd(int op1, int op2)
{
  return op1 + op2;
}

int SysSub(int op1,int op2){
  return op1-op2;
}

int SysCreate(char*name){
      bool flag;
      FileSystem *filesys=new FileSystem();
      flag=filesys->Create(name);
      delete filesys;
      if(!flag){
        return -1;
      }
      else{
        return 1;
      }
}

OpenFileId SysOpen(char*name){
  FileSystem *filesys=new FileSystem();
  OpenFile* openfile;
  openfile=filesys->Open(name);
  //OpenFileId openResult;
  //openResult=openfile->file;
  delete filesys;  //if don't delete it will cause memory leak??
  if(openfile==NULL){
    //printf("open file:%s failed\n",name);
    return -1;
  }
  else{
    return openfile->getOpenFileId();
  }
}

int SysWrite(char*buffer,int size,OpenFileId id){
  OpenFile* openfile=new OpenFile(id);
  int writeResult=openfile->Write(buffer,size);
  //delete openfile;//destructor of Openfile class will call close function to the file
  return writeResult;
}

int SysRead(char*buffer,int size,OpenFileId id){
  OpenFile* openfile=new OpenFile(id);
  int readResult =openfile->Read(buffer,size);
  //delete openfile;//destructor of OpenFile class will call close function to the file
  return readResult;
}

int SysClose(OpenFileId id){
  int closeResult=Close(id);
   return closeResult;
}






#endif /* ! __USERPROG_KSYSCALL_H__ */
