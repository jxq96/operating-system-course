#include "syscall.h"
int main(){
    int result;
    result=Sub(42,23);
    Halt();
}