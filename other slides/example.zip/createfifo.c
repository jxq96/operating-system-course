#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(void)
{
	umask(0);
	if(mkfifo("myfifo",S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP))
	{
		perror("mkfifo error");
		exit(1);
	}
	return 0;
}
