#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#if defined(__GNU_LIBRARY__)&&!defined(_SEM_SEMUN_UNDEFINED)
#else
union semun {
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo* __buf;
};
#endif

int main(void)
{
	key_t unique_key;
	int id;
	struct sembuf lock_it;
	union semun options;
	int i;
	pid_t pid;

	unique_key=ftok(".",'m');

	id=semget(unique_key,1,IPC_CREAT|IPC_EXCL|0666);
	
	options.val=1;

	semctl(id,0,SETVAL,options);

	i=semctl(id,0,GETVAL);
	printf("GETVAL, i=%d\n",i);

	lock_it.sem_num=0;
	lock_it.sem_op=-1;
	lock_it.sem_flg=IPC_NOWAIT;

	if ((pid=fork())<0)
	{
		perror("fork failed");
		exit(1);
	}

	if (pid>0){
		// this is parent
		while(semop(id,&lock_it,1)) 
		{
			printf("parent: cant get, must wait\n");
			sleep(1);
		}
		printf("this is parent using the semphore\n");
		sleep(2);
		lock_it.sem_op=1;
		semop(id,&lock_it,1);
		printf("the semaphore is released by parent\n");
		wait4();
		semctl(id,0,IPC_RMID);
       	}else		
	{
		// this is child
		while(semop(id,&lock_it,1)) 
		{
			printf("can't get, must wait\n");
			sleep(1);
		}
		printf("this is child using the semaphore\n");
		sleep(2);
		lock_it.sem_op=1;
		semop(id,&lock_it,1);
		printf("the semaphore is released by child\n");
	}

}
