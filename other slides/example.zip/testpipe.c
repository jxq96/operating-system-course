#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main(void)
{
	pid_t pid;
	int filedes[2];

	if (pipe(filedes)<0)
	{
		perror("Create pipe error");
		exit(1);
	}

	if ((pid=fork())<0)
	{
		perror("Fork error");
		exit(1);
	}

	if (pid>0)
	{ // this is parent
		close(filedes[0]);
		printf("this is parent\n");
		write(filedes[1],"this is from parent\n",19);
		sleep(1);
		wait4();
		return 0;
	}

	if (pid==0)
	{//this is child
		char buf[1024];
		ssize_t strlen;
		close(filedes[1]);
		printf("this is child\n");
		strlen=read(filedes[0],buf,1024);
		if (strlen>0)
		{
			buf[strlen]='\0';
			printf("%s\n",buf);
		}
		return 0;
	}
}
