#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>

int main(void)
{
	FILE * in_file;
	int count=0;
	char buf[20];
	if ((in_file=fopen("myfifo","r"))<0)
	{
		perror("open fifo for read error");
		exit(1);
	}

	while(count==0)
		count=fread(buf,1,20,in_file);
	printf("%s",buf);
	fclose(in_file);
	return 0;
}
