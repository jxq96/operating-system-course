#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>

int main(void)
{
	FILE * out_file;

	if ((out_file=fopen("myfifo","w"))==NULL)
	{
		perror("open fifo error");
		exit(1);
	}

	fwrite("you are welcome\n",1,20,out_file);
	fclose(out_file);
	return 0;
}
