#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <string.h>
#include <netdb.h>

int main(void)
{
	int sockfd;
	char buffer[100];
	struct sockaddr_in server_addr;
	struct hostent *host;
	int n;

	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if (sockfd==-1)
	{
		perror("socket error");
		exit(1);		
	}


	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(20000);
	inet_pton(AF_INET,"127.0.0.1",&server_addr.sin_addr);

	if(connect(sockfd,(struct sockaddr*)(&server_addr),
				sizeof(struct sockaddr_in))==-1)
	{
		perror("connect failed");
		exit(1);
	}

	n=read(sockfd,buffer,100);
	buffer[n]='\0';
	printf("client read from server: %s\n",buffer);

	write(sockfd,"this is your client",19);

	close(sockfd);
	return 0;
}
