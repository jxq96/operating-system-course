#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <string.h>

int main(void)
{
	int sockfd, new_fd;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	int sin_size;

	if ((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("Socket error");
		exit(1);		
	}

	bzero(&server_addr, sizeof(struct sockaddr_in));
	server_addr.sin_family=AF_INET;
	inet_pton(AF_INET,"127.0.0.1",&server_addr.sin_addr);
	server_addr.sin_port=htons(20000);

	if(bind(sockfd,(struct sockaddr*)(&server_addr),
				sizeof(struct sockaddr))==-1)
	{
		perror("bind error");
		exit(1);
	}
	
	if(listen(sockfd,5)==-1)
	{
		perror("listen error");
		exit(1);
	}
	
	sin_size=sizeof(struct sockaddr_in);
	new_fd=accept(sockfd,(struct sockaddr*)(&client_addr),
				(socklen_t*)(&sin_size));

	//got a client
	int n;
	char buf[100];
	write(new_fd,"who are you",11);
		
	while((n=read(new_fd,buf,100))!=0)
	{
		buf[n]='\0';
		printf("server read from client: %s\n",buf);
	}
	
	close(new_fd);
	close(sockfd);
	return 0;
}
