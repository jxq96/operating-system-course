#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>

int main(void)
{
	key_t key;
	int shm_id;
	const int shm_size=4096;
	char * shm_addr;
	
        key=ftok(".",'m');
	shm_id=shmget(key,shm_size,S_IRUSR|S_IWUSR);

	shm_addr=(char*)shmat(shm_id,0,0);
	
	printf("22222222:");
	printf(shm_addr);
	sprintf(shm_addr,"this is 22222222\n");
	shmdt(shm_addr);
	return 0;
}
