#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>

int main(void)
{
	key_t key;
	int shm_id;
	const int shm_size=4096;
	char * shm_addr;
	
        key=ftok(".",'m');
	shm_id=shmget(key,shm_size,IPC_CREAT|IPC_EXCL|S_IRUSR|S_IWUSR);

	shm_addr=(char*)shmat(shm_id,0,0);

	sprintf(shm_addr,"hello, this is 11111111\n");
	printf("111111:");
	printf(shm_addr);
	sleep(10);
	printf("111111:");
	printf(shm_addr);
	shmdt(shm_addr);
	shmctl(shm_id,IPC_RMID,0);
	return 0;
}
